

// Entrada
const nome = prompt("Nome: ");
const peso = Number(prompt("Peso: "));
const altura = Number(prompt("Altura: "));

console.log(peso);